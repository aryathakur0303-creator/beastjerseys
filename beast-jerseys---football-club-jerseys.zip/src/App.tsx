import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { JerseyCard } from './components/JerseyCard';
import { JerseyModal } from './components/JerseyModal';
import { CartDrawer } from './components/CartDrawer';
import { OrderSteps } from './components/OrderSteps';
import { PolicySection } from './components/PolicySection';
import { Footer } from './components/Footer';
import { 
  FAN_VERSION_JERSEYS, 
  PLAYER_VERSION_JERSEYS, 
  JerseyProductWithImage,
  STORE_PHONE, 
  STORE_WHATSAPP_URL 
} from './data/jerseys';
import { JerseySize, CartItem } from './types';
import { MessageCircle, PackageX, ArrowRight, ShoppingBag } from 'lucide-react';

export default function App() {
  const [selectedJersey, setSelectedJersey] = useState<JerseyProductWithImage | null>(null);
  const [selectedSize, setSelectedSize] = useState<JerseySize>('M');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [activeSection, setActiveSection] = useState('jerseys');
  const [viewVersion, setViewVersion] = useState<'all' | 'player' | 'fan'>('all');

  const cartTotalQuantity = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const handleAddToCart = (jersey: JerseyProductWithImage, size: JerseySize) => {
    const itemKey = `${jersey.id}-${size}`;
    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === itemKey);
      if (existing) {
        return prev.map((i) =>
          i.id === itemKey ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [
        ...prev,
        {
          id: itemKey,
          jerseyId: jersey.id,
          name: jersey.name,
          club: jersey.club,
          version: jersey.version,
          size,
          quantity: 1,
          price: jersey.price,
          imageUrl: jersey.imageUrl,
        },
      ];
    });
  };

  const handleBuyNow = (jersey: JerseyProductWithImage, size: JerseySize) => {
    handleAddToCart(jersey, size);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(itemId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => (item.id === itemId ? { ...item, quantity: newQty } : item))
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== itemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleScrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans">
      
      {/* Header with Cart Button and Instagram link */}
      <Header
        onSelectSection={handleScrollToSection}
        activeSection={activeSection}
        cartCount={cartTotalQuantity}
        onOpenCart={() => setIsCartOpen(true)}
      />

      <main className="flex-1">
        {/* Short & Punchy Hero */}
        <Hero
          onScrollToJerseys={() => handleScrollToSection('jerseys')}
        />

        {/* Available Jerseys — Separate Columns for Player Version and Fan Version */}
        <section id="jerseys" className="py-10 sm:py-16 border-b border-zinc-800 bg-zinc-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
            
            {/* Section Header with Version Filter */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs text-amber-400 font-bold uppercase tracking-wider">
                  2026/27 Football Collection
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-white">
                  Real Madrid & FC Barcelona Away Jerseys
                </h2>
                <p className="text-xs sm:text-sm text-zinc-400">
                  Featured 2026/27 club away jerseys — Just ₹299 with FREE Delivery across India.
                </p>
              </div>

              {/* Version Selector Tabs with "All" instead of "Both Columns" */}
              <div className="inline-flex p-1 bg-zinc-900 border border-zinc-800 rounded-xl shrink-0 self-start md:self-auto">
                <button
                  type="button"
                  onClick={() => setViewVersion('all')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    viewVersion === 'all'
                      ? 'bg-amber-400 text-zinc-950 shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  All
                </button>
                <button
                  type="button"
                  onClick={() => setViewVersion('player')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    viewVersion === 'player'
                      ? 'bg-amber-400 text-zinc-950 shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Player Version
                </button>
                <button
                  type="button"
                  onClick={() => setViewVersion('fan')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    viewVersion === 'fan'
                      ? 'bg-amber-400 text-zinc-950 shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Fan Version
                </button>
              </div>
            </div>

            {/* Separate Columns for Player Version and Fan Version */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              
              {/* COLUMN 1: PLAYER VERSION (EMPTY AS REQUESTED) */}
              {(viewVersion === 'all' || viewVersion === 'player') && (
                <div className="space-y-5 rounded-2xl bg-zinc-900/40 p-4 sm:p-6 border border-zinc-800 flex flex-col justify-between min-h-[420px]">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-zinc-500" />
                        <h3 className="text-lg font-extrabold text-white">Player Version</h3>
                      </div>
                      <p className="text-xs text-zinc-400 mt-0.5">
                        Athletic on-pitch slim fit match edition
                      </p>
                    </div>
                    <span className="text-xs font-medium text-zinc-500 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                      Out of Stock
                    </span>
                  </div>

                  {/* Empty state presentation */}
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-8 space-y-4 border border-dashed border-zinc-800 rounded-xl my-2 bg-zinc-950/40">
                    <div className="w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-500">
                      <PackageX className="w-6 h-6" />
                    </div>
                    <div className="space-y-1 max-w-xs">
                      <h4 className="text-sm font-bold text-white">
                        No Player Version Jerseys Available
                      </h4>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        We currently do not have Player Version in stock. Check our available Fan Version jerseys or inquire on WhatsApp.
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setViewVersion('fan')}
                        className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <span>View Fan Version</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                      <a
                        href={`${STORE_WHATSAPP_URL}?text=${encodeURIComponent(
                          'Hi Beast Jerseys, will you have Player Version jerseys available soon?'
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-amber-400 text-xs font-semibold border border-zinc-800 transition-colors flex items-center gap-1.5"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Inquire on WhatsApp</span>
                      </a>
                    </div>
                  </div>

                  <div className="text-[11px] text-zinc-500 text-center pt-2 border-t border-zinc-800/80">
                    Player Version restocks will be announced on WhatsApp.
                  </div>
                </div>
              )}

              {/* COLUMN 2: FAN VERSION JERSEYS (IN STOCK WITH REAL PHOTOS) */}
              {(viewVersion === 'all' || viewVersion === 'fan') && (
                <div className="space-y-5 rounded-2xl bg-zinc-900/40 p-4 sm:p-6 border border-zinc-800">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                        <h3 className="text-lg font-extrabold text-white">Fan Version</h3>
                      </div>
                      <p className="text-xs text-zinc-400 mt-0.5">
                        Comfortable regular fit · High-quality supporter wear
                      </p>
                    </div>
                    <span className="text-xs font-bold text-emerald-400 bg-emerald-400/10 px-2.5 py-1 rounded-md border border-emerald-400/30">
                      ₹299 · In Stock
                    </span>
                  </div>

                  <div className="space-y-6">
                    {FAN_VERSION_JERSEYS.map((jersey) => (
                      <JerseyCard
                        key={jersey.id}
                        jersey={jersey}
                        onAddToCart={handleAddToCart}
                        onBuyNow={handleBuyNow}
                      />
                    ))}
                  </div>
                </div>
              )}

            </div>

          </div>
        </section>

        {/* Short How to Order Steps */}
        <OrderSteps
          onOrderClick={() => setIsCartOpen(true)}
        />

        {/* Compact Policies Accordion */}
        <PolicySection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating Action Buttons: Cart & WhatsApp */}
      <div className="fixed bottom-4 right-4 z-30 flex flex-col items-end gap-2.5">
        {cartTotalQuantity > 0 && (
          <button
            type="button"
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-zinc-950 font-black text-xs sm:text-sm rounded-full shadow-2xl transition-transform hover:scale-105 cursor-pointer animate-bounce"
            aria-label="View Shopping Cart"
          >
            <ShoppingBag className="w-4 h-4 text-zinc-950" />
            <span>Checkout ({cartTotalQuantity})</span>
          </button>
        )}

        <a
          href={`${STORE_WHATSAPP_URL}?text=${encodeURIComponent('Hi Beast Jerseys, I want to order a jersey.')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs sm:text-sm rounded-full shadow-xl transition-transform hover:scale-105"
          aria-label="Order on WhatsApp"
        >
          <MessageCircle className="w-4 h-4 fill-zinc-950 text-zinc-950" />
          <span>WhatsApp Order</span>
        </a>
      </div>

      {/* Slide-over Cart Drawer with Razorpay Payment Integration */}
      <CartDrawer
        isOpen={isCartOpen}
        cartItems={cartItems}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Order Modal with Real Jersey Photo & Razorpay */}
      <JerseyModal
        jersey={selectedJersey}
        isOpen={isModalOpen}
        initialSize={selectedSize}
        onClose={() => setIsModalOpen(false)}
      />

    </div>
  );
}
