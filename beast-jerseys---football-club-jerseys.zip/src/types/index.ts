export type JerseySize = 'M' | 'L';

export type JerseyVersion = 'Fan Version' | 'Player Version' | 'Master Version';

export interface JerseyStock {
  M: number;
  L: number;
}

export interface JerseyProduct {
  id: string;
  name: string;
  club: 'Real Madrid' | 'FC Barcelona';
  season: string;
  type: string;
  version: JerseyVersion;
  price: number;
  originalPrice: number;
  delivery: string;
  stock: JerseyStock;
  description: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    collar: string;
  };
  features: string[];
  careInstructions: string[];
}

export interface CartItem {
  id: string; // unique item key: e.g. real-madrid-away-fan-M
  jerseyId: string;
  name: string;
  club: 'Real Madrid' | 'FC Barcelona';
  version: JerseyVersion;
  size: JerseySize;
  quantity: number;
  price: number;
  imageUrl: string;
}

