import React, { useState } from 'react';
import { JerseyProductWithImage } from '../data/jerseys';
import { JerseySize } from '../types';
import { STORE_WHATSAPP_URL, STORE_PHONE } from '../data/jerseys';
import { MessageCircle, ShoppingBag, Ruler, Check, Plus } from 'lucide-react';
import { SizeGuideModal } from './SizeGuideModal';

interface JerseyCardProps {
  jersey: JerseyProductWithImage;
  onAddToCart: (jersey: JerseyProductWithImage, selectedSize: JerseySize) => void;
  onBuyNow: (jersey: JerseyProductWithImage, selectedSize: JerseySize) => void;
}

export const JerseyCard: React.FC<JerseyCardProps> = ({ jersey, onAddToCart, onBuyNow }) => {
  const [selectedSize, setSelectedSize] = useState<JerseySize>('M');
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState<boolean>(false);
  const [imgError, setImgError] = useState<boolean>(false);
  const [addedAnimation, setAddedAnimation] = useState<boolean>(false);

  const handleAdd = () => {
    onAddToCart(jersey, selectedSize);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1800);
  };

  return (
    <>
      <article className="group rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-lg">
        
        {/* Real Jersey Photo Showcase */}
        <div className="relative p-3 sm:p-4 pb-0">
          <div className="flex items-center justify-between gap-2 mb-2.5 text-xs text-zinc-400">
            <span className="font-semibold text-zinc-200">{jersey.club} · {jersey.season}</span>
            <span className="text-amber-400 font-bold bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800">
              {jersey.version}
            </span>
          </div>

          <div className="relative aspect-[3/4] sm:aspect-[4/3] w-full rounded-xl overflow-hidden bg-zinc-950 border border-zinc-800/80">
            {!imgError ? (
              <img
                src={jersey.imageUrl}
                alt={jersey.name}
                loading="lazy"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-zinc-900 text-zinc-400">
                <span className="font-bold text-white text-sm">{jersey.name}</span>
                <span className="text-xs text-amber-400 mt-1">₹{jersey.price}</span>
              </div>
            )}

            {/* Overlay Tag */}
            <div className="absolute bottom-2.5 left-2.5 bg-zinc-950/85 backdrop-blur-md px-2.5 py-1 rounded-md border border-zinc-800 text-[11px] text-zinc-200 font-medium">
              {jersey.club} · {jersey.version}
            </div>
          </div>
        </div>

        {/* Content & Ordering Section */}
        <div className="p-4 sm:p-5 space-y-3.5 flex-1 flex flex-col justify-between">
          
          <div className="space-y-3">
            {/* Title & Price */}
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-base sm:text-lg font-bold text-white leading-snug">
                  {jersey.name}
                </h3>
                <p className="text-xs text-zinc-400 line-clamp-2 mt-1">
                  {jersey.description}
                </p>
              </div>
              
              <div className="text-right shrink-0">
                <div className="text-xl sm:text-2xl font-black text-amber-400 tabular-nums">
                  ₹{jersey.price}
                </div>
                <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-wide">
                  Free Delivery
                </div>
              </div>
            </div>

            {/* Clean Size Selector (No stock counters) */}
            <div className="pt-2.5 border-t border-zinc-800/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300 font-medium">Select Size:</span>
                {/* Size Guide Trigger */}
                <button
                  type="button"
                  onClick={() => setIsSizeGuideOpen(true)}
                  className="text-amber-400 hover:text-amber-300 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>Size Guide (M / L)</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedSize('M')}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center transition-colors border cursor-pointer ${
                    selectedSize === 'M'
                      ? 'bg-amber-400/20 border-amber-400 text-amber-300 shadow-sm'
                      : 'bg-zinc-800/80 border-zinc-700 text-zinc-300 hover:border-zinc-600'
                  }`}
                >
                  <span>Size M (38–40&quot;)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedSize('L')}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center transition-colors border cursor-pointer ${
                    selectedSize === 'L'
                      ? 'bg-amber-400/20 border-amber-400 text-amber-300 shadow-sm'
                      : 'bg-zinc-800/80 border-zinc-700 text-zinc-300 hover:border-zinc-600'
                  }`}
                >
                  <span>Size L (40–42&quot;)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Action Row: Add to Cart + Buy Now / Razorpay */}
          <div className="pt-2.5 border-t border-zinc-800/80 space-y-2">
            <div className="grid grid-cols-2 gap-2">
              {/* Add to Cart Button */}
              <button
                type="button"
                onClick={handleAdd}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer border ${
                  addedAnimation
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                    : 'bg-zinc-800 hover:bg-zinc-700 border-zinc-700 text-white'
                }`}
              >
                {addedAnimation ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Added!</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 text-amber-400" />
                    <span>Add to Cart</span>
                  </>
                )}
              </button>

              {/* Buy Now / Checkout with Razorpay */}
              <button
                type="button"
                onClick={() => onBuyNow(jersey, selectedSize)}
                className="py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-zinc-950 font-extrabold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Buy Now (₹{jersey.price})</span>
              </button>
            </div>

            <a
              href={`${STORE_WHATSAPP_URL}?text=${encodeURIComponent(
                `Hi Beast Jerseys, I want to order ${jersey.name} in Size ${selectedSize} (₹${jersey.price}, Free Delivery).`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-1.5 px-3 rounded-lg bg-zinc-800/70 hover:bg-zinc-700 text-zinc-300 hover:text-white text-[11px] font-medium transition-colors flex items-center justify-center gap-1.5 border border-zinc-800"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>Direct WhatsApp Inquiry ({STORE_PHONE})</span>
            </a>
          </div>

        </div>

      </article>

      {/* Size Guide Modal */}
      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
      />
    </>
  );
};
