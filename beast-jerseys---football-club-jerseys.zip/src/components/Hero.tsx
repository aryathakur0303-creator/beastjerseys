import React from 'react';
import { STORE_PHONE, STORE_WHATSAPP_URL } from '../data/jerseys';
import { ArrowDown, MessageCircle, Zap, Truck, Check } from 'lucide-react';

interface HeroProps {
  onScrollToJerseys: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollToJerseys }) => {
  return (
    <section id="hero" className="relative pt-8 pb-10 sm:pt-12 sm:pb-14 border-b border-zinc-800 bg-gradient-to-b from-zinc-950 via-zinc-950 to-zinc-900/60">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center space-y-6">
        
        {/* Subtle Brand Kicker (No Instagram link here, kept only in header) */}
        <div className="inline-flex items-center gap-2 text-xs text-zinc-400 bg-zinc-900/90 border border-zinc-800 px-3.5 py-1.5 rounded-full">
          <span className="text-amber-400 font-bold tracking-wider uppercase">BEAST JERSEYS</span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span>Official 2026/27 Club Away Editions</span>
        </div>

        {/* Clean, Impactful Headline */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-white leading-tight">
          Your Game. Your Jersey. <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-400 to-amber-200">
            Your Identity.
          </span>
        </h1>

        {/* Short, Simple Description */}
        <p className="text-sm sm:text-base text-zinc-300 max-w-2xl mx-auto leading-relaxed">
          Welcome to <strong className="text-white font-semibold">Beast Jerseys</strong>. Real Madrid and FC Barcelona 2026/27 away jerseys at an unbeatable price of just ₹299.
        </p>

        {/* Highlight Offer Callout (No stock counts) */}
        <div className="max-w-xl mx-auto p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-4 text-left">
          <div className="space-y-0.5">
            <div className="text-sm font-extrabold text-amber-400 flex items-center gap-1.5">
              <Zap className="w-4 h-4 fill-amber-400" />
              <span>Special Offer: Jerseys for Just ₹299</span>
            </div>
            <p className="text-xs text-zinc-300">
              FREE Doorstep Delivery across India. Sizes M and L available.
            </p>
          </div>
          <div className="text-right shrink-0">
            <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wide">
              Free Delivery
            </span>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={onScrollToJerseys}
            className="px-6 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-zinc-950 font-extrabold text-sm transition-all shadow-lg shadow-amber-400/15 flex items-center gap-2 cursor-pointer"
          >
            <span>View Jerseys & Order</span>
            <ArrowDown className="w-4 h-4" />
          </button>

          <a
            href={`${STORE_WHATSAPP_URL}?text=${encodeURIComponent(
              'Hi Beast Jerseys, I want to inquire about football jerseys.'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 text-sm font-semibold transition-colors flex items-center gap-2"
          >
            <MessageCircle className="w-4 h-4 text-emerald-400" />
            <span>WhatsApp ({STORE_PHONE})</span>
          </a>
        </div>

        {/* Trust Points (Clean, no stock numbers) */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-zinc-400 pt-2">
          <span className="flex items-center gap-1 text-zinc-300">
            <Check className="w-3.5 h-3.5 text-amber-400" />
            <span>₹299 Flat Price</span>
          </span>
          <span aria-hidden="true" className="text-zinc-700">·</span>
          <span className="flex items-center gap-1 text-zinc-300">
            <Truck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Free All-India Delivery</span>
          </span>
          <span aria-hidden="true" className="text-zinc-700">·</span>
          <span>Prepaid via UPI</span>
          <span aria-hidden="true" className="text-zinc-700">·</span>
          <span>Sizes M & L Available</span>
        </div>

      </div>
    </section>
  );
};
