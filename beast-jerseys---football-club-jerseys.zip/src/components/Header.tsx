import React, { useState } from 'react';
import { STORE_PHONE, STORE_WHATSAPP_URL, STORE_INSTAGRAM, STORE_INSTAGRAM_URL } from '../data/jerseys';
import { MessageCircle, Menu, X, Instagram, ShoppingBag } from 'lucide-react';

interface HeaderProps {
  onSelectSection: (sectionId: string) => void;
  activeSection?: string;
  cartCount: number;
  onOpenCart: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  onSelectSection, 
  activeSection = 'jerseys',
  cartCount,
  onOpenCart,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (sectionId: string) => {
    onSelectSection(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Top Banner: ₹299 Special Offer with Free Delivery */}
      <aside aria-label="Special Offer" className="bg-zinc-900 border-b border-zinc-800 px-4 py-2 text-xs text-zinc-300">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-400" />
            <span>Special Offer: Football Jerseys for Just <strong className="text-amber-400">₹299</strong> — FREE DELIVERY across India</span>
          </div>
          <div className="text-xs text-zinc-400 hidden sm:block">
            Prepaid Razorpay & UPI · Direct Dispatch
          </div>
        </div>
      </aside>

      {/* Main Navigation Bar */}
      <header className="sticky top-0 z-40 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-6 px-4 sm:px-6 py-3.5">
          {/* Brand Name (Without trophy emoji) */}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('hero');
            }}
            className="text-lg sm:text-xl font-extrabold tracking-tight text-white hover:text-amber-400 transition-colors whitespace-nowrap shrink-0"
          >
            BEAST JERSEYS
          </a>

          {/* Simple Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-zinc-400">
            <button
              onClick={() => handleNavClick('jerseys')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSection === 'jerseys' ? 'text-amber-400 font-semibold' : ''
              }`}
            >
              Jersey Collection
            </button>
            <button
              onClick={() => handleNavClick('how-to-order')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSection === 'how-to-order' ? 'text-amber-400 font-semibold' : ''
              }`}
            >
              How to Order
            </button>
            <button
              onClick={() => handleNavClick('policies')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSection === 'policies' ? 'text-amber-400 font-semibold' : ''
              }`}
            >
              Policies
            </button>
          </nav>

          {/* Actions: Instagram, Cart Button, and WhatsApp */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            {/* The single official Instagram link on the site */}
            <a
              href={STORE_INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 sm:px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-pink-400 border border-zinc-800 transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title="Follow @beast.jersey on Instagram"
            >
              <Instagram className="w-3.5 h-3.5 text-pink-400" />
              <span className="hidden sm:inline">@{STORE_INSTAGRAM}</span>
            </a>

            {/* Shopping Cart Button */}
            <button
              type="button"
              onClick={onOpenCart}
              className="relative p-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-amber-400 border border-zinc-800 transition-colors flex items-center gap-2 text-xs font-bold cursor-pointer"
              aria-label="Open Shopping Cart"
            >
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Cart</span>
              {cartCount > 0 && (
                <span className="min-w-4 h-4 px-1 rounded-full bg-amber-400 text-zinc-950 font-black text-[10px] flex items-center justify-center tabular-nums">
                  {cartCount}
                </span>
              )}
            </button>

            {/* WhatsApp Contact */}
            <a
              href={`${STORE_WHATSAPP_URL}?text=${encodeURIComponent(
                'Hi Beast Jerseys, I want to inquire about football jerseys.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 sm:px-4 py-2 text-xs sm:text-sm font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm"
            >
              <MessageCircle className="w-4 h-4 fill-zinc-950 text-zinc-950" />
              <span className="hidden sm:inline">WhatsApp</span>
            </a>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-zinc-400 hover:text-white md:hidden rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-zinc-800 bg-zinc-900/95 px-4 py-4 space-y-3">
            <button
              onClick={() => handleNavClick('jerseys')}
              className="block w-full text-left py-2 text-sm font-medium text-zinc-300 hover:text-amber-400"
            >
              Jersey Collection
            </button>
            <button
              onClick={() => handleNavClick('how-to-order')}
              className="block w-full text-left py-2 text-sm font-medium text-zinc-300 hover:text-amber-400"
            >
              How to Order
            </button>
            <button
              onClick={() => handleNavClick('policies')}
              className="block w-full text-left py-2 text-sm font-medium text-zinc-300 hover:text-amber-400"
            >
              Return & Shipping Policies
            </button>
            <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenCart();
                }}
                className="flex items-center gap-1.5 text-amber-400 font-bold"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>View Cart ({cartCount})</span>
              </button>
              <span>WhatsApp: {STORE_PHONE}</span>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
