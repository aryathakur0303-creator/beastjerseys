import React, { useState } from 'react';
import { STORE_PHONE, STORE_UPI_ID } from '../data/jerseys';
import { X, ShieldCheck, CheckCircle2, CreditCard, Smartphone, Building2, Wallet } from 'lucide-react';

interface RazorpayModalProps {
  isOpen: boolean;
  amount: number;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  itemsSummary: string;
  onClose: () => void;
  onPaymentSuccess: (paymentId: string) => void;
}

export const RazorpayModal: React.FC<RazorpayModalProps> = ({
  isOpen,
  amount,
  customerName,
  customerPhone,
  customerAddress,
  itemsSummary,
  onClose,
  onPaymentSuccess,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [upiVpa, setUpiVpa] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleSimulatePayment = (methodName: string) => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const generatedPayId = `pay_${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 899 + 100)}`;
      onPaymentSuccess(generatedPayId);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm">
      <div 
        className="relative w-full max-w-md bg-white text-zinc-900 rounded-2xl shadow-2xl overflow-hidden border border-zinc-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Razorpay Brand Header */}
        <div className="bg-[#0c2340] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-blue-500 text-white flex items-center justify-center font-bold text-sm">
              R
            </div>
            <div>
              <div className="text-xs font-bold tracking-wide uppercase text-blue-200">Razorpay Trusted Checkout</div>
              <div className="text-sm font-extrabold text-white">Beast Jerseys</div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Amount Banner */}
        <div className="bg-[#f2f7ff] border-b border-blue-100 px-5 py-3 flex items-center justify-between">
          <div className="text-xs text-zinc-600">
            <span>Payable Amount:</span>
            <div className="text-[11px] text-zinc-500 truncate max-w-[220px]">{itemsSummary}</div>
          </div>
          <div className="text-xl font-black text-blue-900 tabular-nums">
            ₹{amount}
          </div>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          {isProcessing ? (
            <div className="py-12 flex flex-col items-center justify-center space-y-3 text-center">
              <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
              <div className="text-sm font-bold text-zinc-800">Processing Razorpay Payment...</div>
              <p className="text-xs text-zinc-500">Please do not refresh or close this window</p>
            </div>
          ) : (
            <>
              {/* Payment Methods Tabs */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    paymentMethod === 'upi'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-bold'
                      : 'border-zinc-200 hover:border-zinc-300 text-zinc-600'
                  }`}
                >
                  <Smartphone className="w-4 h-4 mx-auto mb-1 text-blue-600" />
                  <span className="text-xs block">UPI / QR</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-bold'
                      : 'border-zinc-200 hover:border-zinc-300 text-zinc-600'
                  }`}
                >
                  <CreditCard className="w-4 h-4 mx-auto mb-1 text-blue-600" />
                  <span className="text-xs block">Cards</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('netbanking')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    paymentMethod === 'netbanking'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-bold'
                      : 'border-zinc-200 hover:border-zinc-300 text-zinc-600'
                  }`}
                >
                  <Building2 className="w-4 h-4 mx-auto mb-1 text-blue-600" />
                  <span className="text-xs block">NetBanking</span>
                </button>
              </div>

              {/* Method Detail View */}
              {paymentMethod === 'upi' && (
                <div className="space-y-3 pt-1">
                  <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-200 space-y-2">
                    <span className="text-xs font-bold text-zinc-700">Instant UPI Apps:</span>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleSimulatePayment('Google Pay')}
                        className="p-2 rounded-lg border border-zinc-200 hover:border-blue-500 hover:bg-white text-xs font-semibold text-zinc-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span className="w-2 h-2 rounded-full bg-emerald-500" />
                        <span>Google Pay</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSimulatePayment('PhonePe')}
                        className="p-2 rounded-lg border border-zinc-200 hover:border-blue-500 hover:bg-white text-xs font-semibold text-zinc-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span className="w-2 h-2 rounded-full bg-purple-600" />
                        <span>PhonePe</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSimulatePayment('Paytm')}
                        className="p-2 rounded-lg border border-zinc-200 hover:border-blue-500 hover:bg-white text-xs font-semibold text-zinc-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span className="w-2 h-2 rounded-full bg-sky-500" />
                        <span>Paytm UPI</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSimulatePayment('BHIM')}
                        className="p-2 rounded-lg border border-zinc-200 hover:border-blue-500 hover:bg-white text-xs font-semibold text-zinc-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span className="w-2 h-2 rounded-full bg-orange-500" />
                        <span>BHIM / Cred</span>
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-zinc-600 font-medium">Or enter UPI ID / VPA:</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="yourname@okaxis"
                        value={upiVpa}
                        onChange={(e) => setUpiVpa(e.target.value)}
                        className="flex-1 px-3 py-2 text-xs border border-zinc-300 rounded-lg focus:outline-none focus:border-blue-600 text-zinc-900"
                      />
                      <button
                        type="button"
                        onClick={() => handleSimulatePayment('UPI VPA')}
                        className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer"
                      >
                        Pay ₹{amount}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'card' && (
                <div className="space-y-2.5 pt-1 text-xs">
                  <div>
                    <label className="text-zinc-600 font-medium">Card Number</label>
                    <input
                      type="text"
                      placeholder="4111 2222 3333 4444"
                      className="w-full mt-1 px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:border-blue-600"
                      defaultValue="4242 •••• •••• 4242"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-zinc-600 font-medium">Expiry</label>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        className="w-full mt-1 px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:border-blue-600"
                        defaultValue="12/28"
                      />
                    </div>
                    <div>
                      <label className="text-zinc-600 font-medium">CVV</label>
                      <input
                        type="password"
                        placeholder="•••"
                        maxLength={3}
                        className="w-full mt-1 px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:border-blue-600"
                        defaultValue="123"
                      />
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleSimulatePayment('Credit/Debit Card')}
                    className="w-full mt-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
                  >
                    Pay ₹{amount} with Card
                  </button>
                </div>
              )}

              {paymentMethod === 'netbanking' && (
                <div className="space-y-2.5 pt-1 text-xs">
                  <span className="text-zinc-600 font-medium">Select Popular Bank:</span>
                  <div className="grid grid-cols-2 gap-2">
                    {['State Bank of India', 'HDFC Bank', 'ICICI Bank', 'Axis Bank'].map((b) => (
                      <button
                        key={b}
                        type="button"
                        onClick={() => handleSimulatePayment(b)}
                        className="p-2 rounded-lg border border-zinc-200 hover:border-blue-500 hover:bg-blue-50/50 text-xs font-semibold text-zinc-800 text-left transition-colors cursor-pointer"
                      >
                        {b}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Security info */}
              <div className="pt-2 flex items-center justify-between text-[11px] text-zinc-500 border-t border-zinc-100">
                <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>256-Bit SSL Encrypted by Razorpay</span>
                </div>
                <span>India Compliant</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
