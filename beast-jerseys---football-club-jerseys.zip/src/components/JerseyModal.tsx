import React, { useState, useEffect } from 'react';
import { JerseyProductWithImage } from '../data/jerseys';
import { JerseySize } from '../types';
import { STORE_PHONE, STORE_UPI_ID, STORE_WHATSAPP_URL } from '../data/jerseys';
import { generateUPIQRCode, generateUPILink } from '../utils/upi';
import { openRazorpayCheckout } from '../utils/razorpay';
import { RazorpayModal } from './RazorpayModal';
import { 
  X, 
  Check, 
  Copy, 
  MessageCircle, 
  Truck, 
  QrCode, 
  ExternalLink,
  Ruler,
  CreditCard,
  CheckCircle2
} from 'lucide-react';
import { SizeGuideModal } from './SizeGuideModal';

interface JerseyModalProps {
  jersey: JerseyProductWithImage | null;
  isOpen: boolean;
  initialSize?: JerseySize;
  onClose: () => void;
}

export const JerseyModal: React.FC<JerseyModalProps> = ({
  jersey,
  isOpen,
  initialSize = 'M',
  onClose,
}) => {
  const [selectedSize, setSelectedSize] = useState<JerseySize>(initialSize);
  const [quantity, setQuantity] = useState<number>(1);
  const [name, setName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [pincode, setPincode] = useState<string>('');
  const [copiedUpi, setCopiedUpi] = useState<boolean>(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState<boolean>(false);
  const [showRazorpayModal, setShowRazorpayModal] = useState<boolean>(false);
  const [completedPaymentId, setCompletedPaymentId] = useState<string | null>(null);

  useEffect(() => {
    if (initialSize) {
      setSelectedSize(initialSize);
    }
  }, [initialSize, isOpen]);

  useEffect(() => {
    if (!jersey) return;
    const totalAmount = jersey.price * quantity;
    const note = `Beast Jerseys: ${jersey.club} ${jersey.version} ${selectedSize} (Qty ${quantity})`;

    generateUPIQRCode({
      amount: totalAmount,
      note,
    }).then((url) => {
      setQrCodeDataUrl(url);
    });
  }, [jersey, quantity, selectedSize]);

  if (!isOpen || !jersey) return null;

  const totalPrice = jersey.price * quantity;

  const handleCopyUPI = async () => {
    try {
      await navigator.clipboard.writeText(STORE_UPI_ID);
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2500);
    } catch {
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2500);
    }
  };

  const handleRazorpayClick = () => {
    const opened = openRazorpayCheckout({
      amount: totalPrice,
      orderName: `${jersey.name} (${selectedSize})`,
      description: `${jersey.club} ${jersey.version} - Size ${selectedSize} (Qty ${quantity})`,
      customerName: name,
      customerPhone: phone,
      customerAddress: `${address} - ${pincode}`,
      onSuccess: (payId) => {
        setCompletedPaymentId(payId);
      },
      onError: () => {
        setShowRazorpayModal(true);
      },
    });

    if (!opened) {
      setShowRazorpayModal(true);
    }
  };

  const formattedWhatsAppMessage = `🏆 *BEAST JERSEYS ORDER INQUIRY*
-----------------------------
👕 *Club Jersey:* ${jersey.name}
✨ *Version:* ${jersey.version}
📏 *Selected Size:* ${selectedSize}
🔢 *Quantity:* ${quantity}
💰 *Total Price:* ₹${totalPrice} (FREE DELIVERY)
${completedPaymentId ? `💳 *Razorpay Payment ID:* ${completedPaymentId} (PAID)\n` : ''}
👤 *Customer Name:* ${name.trim() || '[To be provided]'}
📞 *Phone Number:* ${phone.trim() || '[To be provided]'}
📍 *Delivery Address:* ${address.trim() || '[To be provided]'}
📮 *Pincode:* ${pincode.trim() || '[To be provided]'}

Hi Beast Jerseys, I want to confirm my order and receive dispatch tracking!`;

  const whatsAppUrl = `${STORE_WHATSAPP_URL}?text=${encodeURIComponent(formattedWhatsAppMessage)}`;
  const upiDeepLink = generateUPILink({
    amount: totalPrice,
    note: `BeastJerseys-${jersey.club}-${selectedSize}`,
  });

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
        <div 
          className="relative w-full max-w-2xl my-6 bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden"
          role="dialog"
          aria-modal="true"
        >
          {/* Modal Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-900/90">
            <div>
              <h3 className="font-bold text-white text-base">
                Order {jersey.name} ({jersey.version})
              </h3>
              <p className="text-xs text-zinc-400">
                ₹{jersey.price} · FREE All-India Doorstep Delivery
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="p-4 sm:p-6 max-h-[78vh] overflow-y-auto space-y-4">
            
            {completedPaymentId ? (
              <div className="p-6 rounded-2xl bg-zinc-900 border border-emerald-500/30 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white">Payment Successful!</h4>
                  <p className="text-xs text-zinc-400 mt-1">Paid via Razorpay Secure Gateway</p>
                  <div className="mt-2 p-2 rounded bg-zinc-950 border border-zinc-800 font-mono text-xs text-amber-400">
                    Payment ID: {completedPaymentId}
                  </div>
                </div>

                <a
                  href={whatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black text-sm transition-all flex items-center justify-center gap-2 shadow-lg"
                >
                  <MessageCircle className="w-5 h-5 fill-zinc-950 text-zinc-950" />
                  <span>Send Confirmation to WhatsApp ({STORE_PHONE})</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    setCompletedPaymentId(null);
                    onClose();
                  }}
                  className="text-xs text-zinc-400 hover:text-white underline cursor-pointer"
                >
                  Done
                </button>
              </div>
            ) : (
              <>
                {/* Jersey Preview Row with Real Image */}
                <div className="flex flex-col sm:flex-row gap-3.5 p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 items-center">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-lg overflow-hidden bg-zinc-950 border border-zinc-800 shrink-0">
                    <img
                      src={jersey.imageUrl}
                      alt={jersey.name}
                      className="w-full h-full object-cover object-center"
                    />
                  </div>

                  <div className="flex-1 space-y-1 text-center sm:text-left">
                    <div className="text-xs font-semibold text-amber-400">{jersey.club} · {jersey.version}</div>
                    <h4 className="text-sm sm:text-base font-bold text-white">{jersey.name}</h4>
                    <p className="text-xs text-zinc-400 line-clamp-2">{jersey.description}</p>
                    <div className="text-xs text-emerald-400 font-semibold pt-1">
                      ₹{jersey.price} Flat · Free Delivery
                    </div>
                  </div>
                </div>

                {/* Size & Quantity Selection */}
                <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-zinc-300 font-medium">Select Size:</span>
                    <button
                      type="button"
                      onClick={() => setIsSizeGuideOpen(true)}
                      className="text-amber-400 hover:underline text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Ruler className="w-3.5 h-3.5" />
                      <span>Size Chart (M / L)</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedSize('M')}
                      className={`py-2 px-3 rounded-lg text-xs font-semibold border flex items-center justify-center cursor-pointer ${
                        selectedSize === 'M'
                          ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                          : 'bg-zinc-800 border-zinc-700 text-zinc-300'
                      }`}
                    >
                      <span>Size M (38–40&quot;)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedSize('L')}
                      className={`py-2 px-3 rounded-lg text-xs font-semibold border flex items-center justify-center cursor-pointer ${
                        selectedSize === 'L'
                          ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                          : 'bg-zinc-800 border-zinc-700 text-zinc-300'
                      }`}
                    >
                      <span>Size L (40–42&quot;)</span>
                    </button>
                  </div>

                  {/* Quantity */}
                  <div className="flex items-center justify-between pt-2 border-t border-zinc-800 text-xs">
                    <span className="text-zinc-400">Quantity:</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={quantity <= 1}
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-8 h-7 rounded bg-zinc-800 hover:bg-zinc-700 text-white disabled:opacity-40 font-bold border border-zinc-700 cursor-pointer"
                      >
                        -
                      </button>
                      <span className="w-8 text-center font-bold text-white tabular-nums">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => setQuantity(quantity + 1)}
                        className="w-8 h-7 rounded bg-zinc-800 hover:bg-zinc-700 text-white font-bold border border-zinc-700 cursor-pointer"
                      >
                        +
                      </button>
                      <span className="ml-2 font-bold text-amber-400 text-sm tabular-nums">
                        Total: ₹{totalPrice}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Delivery Inputs */}
                <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2.5">
                  <span className="text-xs font-bold text-zinc-300 block uppercase tracking-wider">
                    Shipping Details (For Razorpay & WhatsApp)
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <input
                      type="text"
                      placeholder="Your Full Name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs placeholder:text-zinc-600 focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="tel"
                      placeholder="Phone / WhatsApp Number"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs placeholder:text-zinc-600 focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="text"
                      placeholder="Delivery Address, City"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="sm:col-span-2 px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs placeholder:text-zinc-600 focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="text"
                      placeholder="PIN Code"
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value)}
                      className="px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs placeholder:text-zinc-600 focus:outline-none focus:border-amber-400"
                    />
                    <div className="flex items-center text-xs text-emerald-400 gap-1.5">
                      <Truck className="w-4 h-4" />
                      <span>Free All-India Doorstep Delivery</span>
                    </div>
                  </div>
                </div>

                {/* Payment Options */}
                <div className="space-y-3 pt-1">
                  {/* Primary Razorpay Action */}
                  <button
                    type="button"
                    onClick={handleRazorpayClick}
                    className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>Pay ₹{totalPrice} with Razorpay (Cards, UPI, NetBanking)</span>
                  </button>

                  {/* Secondary WhatsApp Action */}
                  <a
                    href={whatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 fill-zinc-950 text-zinc-950" />
                    <span>Or Order via WhatsApp ({STORE_PHONE})</span>
                  </a>

                  <p className="text-[11px] text-zinc-500 text-center">
                    Unboxing video required for any defect exchange. Free shipping included.
                  </p>
                </div>
              </>
            )}

          </div>
        </div>
      </div>

      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
      />

      <RazorpayModal
        isOpen={showRazorpayModal}
        amount={totalPrice}
        customerName={name}
        customerPhone={phone}
        customerAddress={`${address} - ${pincode}`}
        itemsSummary={`${jersey.name} (${selectedSize}) x${quantity}`}
        onClose={() => setShowRazorpayModal(false)}
        onPaymentSuccess={(payId) => {
          setShowRazorpayModal(false);
          setCompletedPaymentId(payId);
        }}
      />
    </>
  );
};
