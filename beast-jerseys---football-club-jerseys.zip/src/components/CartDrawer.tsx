import React, { useState } from 'react';
import { CartItem } from '../types';
import { STORE_PHONE, STORE_WHATSAPP_URL, STORE_UPI_ID } from '../data/jerseys';
import { openRazorpayCheckout } from '../utils/razorpay';
import { RazorpayModal } from './RazorpayModal';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Truck, 
  ShieldCheck, 
  CreditCard, 
  CheckCircle2, 
  MessageCircle,
  ArrowRight,
  ExternalLink
} from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  cartItems: CartItem[];
  onClose: () => void;
  onUpdateQuantity: (itemId: string, newQty: number) => void;
  onRemoveItem: (itemId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  cartItems,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [showRazorpayModal, setShowRazorpayModal] = useState(false);
  const [completedPaymentId, setCompletedPaymentId] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalQuantity = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const itemsSummary = cartItems.map((i) => `${i.name} (${i.size}) x${i.quantity}`).join(', ');

  const handleStartPayment = () => {
    if (cartItems.length === 0) return;

    // First attempt to open standard Razorpay checkout SDK
    const opened = openRazorpayCheckout({
      amount: subtotal,
      orderName: 'Beast Jerseys Order',
      description: itemsSummary,
      customerName: name,
      customerPhone: phone,
      customerAddress: `${address} - ${pincode}`,
      onSuccess: (paymentId) => {
        setCompletedPaymentId(paymentId);
      },
      onError: () => {
        // Fallback to Razorpay interactive modal
        setShowRazorpayModal(true);
      },
      onDismiss: () => {
        console.log('Razorpay modal dismissed');
      },
    });

    if (!opened) {
      // If SDK not loaded or key invalid, show interactive Razorpay checkout modal
      setShowRazorpayModal(true);
    }
  };

  const handleRazorpaySuccess = (payId: string) => {
    setShowRazorpayModal(false);
    setCompletedPaymentId(payId);
  };

  const formattedWhatsAppReceipt = `🏆 *BEAST JERSEYS ORDER — RAZORPAY PAID*
---------------------------------------
💳 *Payment Status:* PAID via Razorpay
🆔 *Payment ID:* ${completedPaymentId || 'PENDING'}
💰 *Total Amount:* ₹${subtotal} (FREE DELIVERY)

📦 *Ordered Items:*
${cartItems.map((item, idx) => `${idx + 1}. ${item.name} (${item.version}) - Size ${item.size} x${item.quantity} = ₹${item.price * item.quantity}`).join('\n')}

👤 *Customer Name:* ${name.trim() || '[To be provided]'}
📞 *Phone Number:* ${phone.trim() || '[To be provided]'}
📍 *Delivery Address:* ${address.trim() || '[To be provided]'}
📮 *Pincode:* ${pincode.trim() || '[To be provided]'}

Hi Beast Jerseys, I have completed payment for my order via Razorpay. Please verify and share dispatch tracking!`;

  const whatsAppUrl = `${STORE_WHATSAPP_URL}?text=${encodeURIComponent(formattedWhatsAppReceipt)}`;

  return (
    <>
      <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm transition-opacity">
        <div 
          className="relative w-full max-w-md bg-zinc-950 border-l border-zinc-800 h-full flex flex-col shadow-2xl overflow-hidden"
          role="dialog"
          aria-modal="true"
        >
          {/* Drawer Header */}
          <div className="p-4 sm:p-5 border-b border-zinc-800 bg-zinc-900/90 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-white">Your Shopping Bag</h2>
              <span className="text-xs text-zinc-400 font-medium">
                ({totalQuantity} {totalQuantity === 1 ? 'jersey' : 'jerseys'})
              </span>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {completedPaymentId ? (
              /* Success Screen */
              <div className="p-5 rounded-2xl bg-zinc-900 border border-emerald-500/30 text-center space-y-4 my-auto">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Payment Received!</h3>
                  <p className="text-xs text-zinc-400 mt-1">
                    Your order was paid via Razorpay.
                  </p>
                  <div className="mt-2 p-2 rounded bg-zinc-950 border border-zinc-800 font-mono text-xs text-amber-400">
                    ID: {completedPaymentId}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-zinc-950 text-left text-xs text-zinc-300 space-y-1">
                  <div className="font-bold text-white">Summary:</div>
                  <div className="text-[11px] text-zinc-400">{itemsSummary}</div>
                  <div className="font-bold text-amber-400 pt-1">Total Paid: ₹{subtotal} (Free Delivery)</div>
                </div>

                <a
                  href={whatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-extrabold text-xs transition-colors flex items-center justify-center gap-2 shadow-lg"
                >
                  <MessageCircle className="w-4 h-4 fill-zinc-950" />
                  <span>Send Order to WhatsApp ({STORE_PHONE})</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    onClearCart();
                    setCompletedPaymentId(null);
                    onClose();
                  }}
                  className="text-xs text-zinc-400 hover:text-zinc-200 underline cursor-pointer"
                >
                  Close and Continue Shopping
                </button>
              </div>
            ) : cartItems.length === 0 ? (
              /* Empty Cart */
              <div className="py-16 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-500 mx-auto flex items-center justify-center">
                  <ShoppingBag className="w-7 h-7" />
                </div>
                <h3 className="text-sm font-bold text-white">Your Bag is Empty</h3>
                <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                  Add Real Madrid or FC Barcelona away jerseys to your bag for just ₹299 with free all-India delivery.
                </p>
                <button
                  type="button"
                  onClick={onClose}
                  className="mt-2 px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs transition-colors cursor-pointer"
                >
                  Browse Available Jerseys
                </button>
              </div>
            ) : (
              /* Cart Items List */
              <>
                <div className="space-y-3">
                  {cartItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center gap-3"
                    >
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-16 h-16 rounded-lg object-cover bg-zinc-950 border border-zinc-800 shrink-0"
                      />
                      <div className="flex-1 min-w-0 space-y-1">
                        <h4 className="text-xs font-bold text-white truncate">{item.name}</h4>
                        <div className="text-[11px] text-zinc-400">
                          {item.version} · <strong className="text-amber-400">Size {item.size}</strong>
                        </div>
                        <div className="text-xs font-bold text-white tabular-nums">
                          ₹{item.price} each
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-2">
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.id)}
                          className="text-zinc-500 hover:text-rose-400 p-1 transition-colors cursor-pointer"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        <div className="flex items-center gap-1.5 bg-zinc-950 border border-zinc-800 rounded-md p-0.5">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                            className="w-5 h-5 flex items-center justify-center text-zinc-400 hover:text-white rounded cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-5 text-center text-xs font-bold text-white tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                            className="w-5 h-5 flex items-center justify-center text-zinc-400 hover:text-white rounded cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Shipping & Delivery Info */}
                <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2.5">
                  <span className="text-xs font-bold text-zinc-300 block uppercase tracking-wider">
                    Shipping Details (For Dispatch)
                  </span>
                  <div className="space-y-2">
                    <input
                      type="text"
                      placeholder="Your Full Name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs placeholder:text-zinc-500 focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="tel"
                      placeholder="WhatsApp / Phone Number"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs placeholder:text-zinc-500 focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="text"
                      placeholder="Delivery Address, City"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs placeholder:text-zinc-500 focus:outline-none focus:border-amber-400"
                    />
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="PIN Code"
                        value={pincode}
                        onChange={(e) => setPincode(e.target.value)}
                        className="flex-1 px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs placeholder:text-zinc-500 focus:outline-none focus:border-amber-400"
                      />
                      <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold px-2">
                        <Truck className="w-3.5 h-3.5" />
                        <span>Free Shipping</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2 text-xs">
                  <div className="flex justify-between text-zinc-400">
                    <span>Subtotal ({totalQuantity} items):</span>
                    <span className="text-white font-medium tabular-nums">₹{subtotal}</span>
                  </div>
                  <div className="flex justify-between text-zinc-400">
                    <span>Delivery Charge:</span>
                    <span className="text-emerald-400 font-semibold uppercase">FREE</span>
                  </div>
                  <div className="pt-2 border-t border-zinc-800 flex justify-between text-sm font-bold text-white">
                    <span>Total Amount Payable:</span>
                    <span className="text-amber-400 tabular-nums">₹{subtotal}</span>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Drawer Footer with Razorpay Checkout */}
          {!completedPaymentId && cartItems.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-zinc-800 bg-zinc-900/95 space-y-2.5 shrink-0">
              {/* Primary Razorpay Checkout Button */}
              <button
                type="button"
                onClick={handleStartPayment}
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
              >
                <CreditCard className="w-4 h-4" />
                <span>Pay ₹{subtotal} with Razorpay (Cards, UPI, NetBanking)</span>
              </button>

              {/* Direct WhatsApp Option */}
              <a
                href={`${STORE_WHATSAPP_URL}?text=${encodeURIComponent(
                  `Hi Beast Jerseys! I would like to order: ${itemsSummary}. Total: ₹${subtotal} (Free Delivery). Name: ${name || 'N/A'}, Phone: ${phone || 'N/A'}`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-300 hover:text-white text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 border border-zinc-700"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>Or Order via WhatsApp ({STORE_PHONE})</span>
              </a>

              <div className="flex items-center justify-center gap-2 text-[10px] text-zinc-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                <span>Secure 256-Bit SSL Payments Powered by Razorpay</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Razorpay Interactive Modal */}
      <RazorpayModal
        isOpen={showRazorpayModal}
        amount={subtotal}
        customerName={name}
        customerPhone={phone}
        customerAddress={`${address} ${pincode}`}
        itemsSummary={itemsSummary}
        onClose={() => setShowRazorpayModal(false)}
        onPaymentSuccess={handleRazorpaySuccess}
      />
    </>
  );
};
