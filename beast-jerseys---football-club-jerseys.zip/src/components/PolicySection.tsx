import React, { useState } from 'react';
import { STORE_PHONE, STORE_UPI_ID } from '../data/jerseys';
import { ChevronDown, Video, Truck, ShieldCheck, FileText, Lock } from 'lucide-react';

export const PolicySection: React.FC = () => {
  const [openPolicy, setOpenPolicy] = useState<string | null>('returns');

  const togglePolicy = (id: string) => {
    setOpenPolicy(openPolicy === id ? null : id);
  };

  return (
    <section id="policies" className="py-10 sm:py-14 border-b border-zinc-800 bg-zinc-950/60">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        
        <div className="text-center space-y-1">
          <span className="text-xs text-amber-400 font-bold uppercase tracking-wider">
            Important Information
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Store Policies & Customer Guarantee
          </h2>
          <p className="text-xs text-zinc-400">
            Clear guidelines on returns, exchanges, shipping, and terms.
          </p>
        </div>

        {/* Compact Accordion */}
        <div className="space-y-3">
          
          {/* 1. Return & Exchange Policy */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900 overflow-hidden">
            <button
              type="button"
              onClick={() => togglePolicy('returns')}
              className="w-full p-4 text-left flex items-center justify-between text-sm font-bold text-white hover:bg-zinc-800/40 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Video className="w-4 h-4 text-amber-400" />
                <span>Return, Exchange & Refund Policy (Unboxing Video Requirement)</span>
              </div>
              <ChevronDown className={`w-4 h-4 text-zinc-400 transition-transform ${openPolicy === 'returns' ? 'rotate-180' : ''}`} />
            </button>

            {openPolicy === 'returns' && (
              <div className="p-4 pt-1 border-t border-zinc-800/80 text-xs text-zinc-300 space-y-3">
                <div className="p-3 rounded-lg bg-amber-400/10 border border-amber-400/30 text-amber-300">
                  <strong>Mandatory Package-Opening Video:</strong> To request an exchange for genuine defects or damage attributable to us, you must record a clear, continuous, unedited video while opening the original, unopened package showing the shipping label and product defect.
                </div>
                <p>
                  • <strong>Returns:</strong> We generally do not accept returns for change of mind, incorrect size selection, or personal preference. Please confirm your size before ordering.
                </p>
                <p>
                  • <strong>Exchanges:</strong> Considered only for verified defects attributable to Beast Jerseys or damaged transit items with valid video proof. Contact us promptly on WhatsApp at {STORE_PHONE}.
                </p>
                <p>
                  • <strong>Refunds:</strong> Subject to applicable consumer protection laws for verified defects where an exchange cannot be fulfilled.
                </p>
              </div>
            )}
          </div>

          {/* 2. Shipping & Delivery Policy */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900 overflow-hidden">
            <button
              type="button"
              onClick={() => togglePolicy('shipping')}
              className="w-full p-4 text-left flex items-center justify-between text-sm font-bold text-white hover:bg-zinc-800/40 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Truck className="w-4 h-4 text-emerald-400" />
                <span>Shipping & Delivery Policy (FREE All-India Delivery)</span>
              </div>
              <ChevronDown className={`w-4 h-4 text-zinc-400 transition-transform ${openPolicy === 'shipping' ? 'rotate-180' : ''}`} />
            </button>

            {openPolicy === 'shipping' && (
              <div className="p-4 pt-1 border-t border-zinc-800/80 text-xs text-zinc-300 space-y-2">
                <p>• <strong>Free Delivery:</strong> Included in the advertised ₹299 jersey price across India. No extra delivery charges.</p>
                <p>• <strong>Timelines:</strong> Communicated directly on WhatsApp upon order verification and package dispatch.</p>
                <p>• <strong>Customer Info:</strong> Please provide a complete delivery address, pin code, and active phone number.</p>
              </div>
            )}
          </div>

          {/* 3. Terms & Privacy */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900 overflow-hidden">
            <button
              type="button"
              onClick={() => togglePolicy('terms')}
              className="w-full p-4 text-left flex items-center justify-between text-sm font-bold text-white hover:bg-zinc-800/40 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <FileText className="w-4 h-4 text-zinc-400" />
                <span>Terms & Privacy Summary</span>
              </div>
              <ChevronDown className={`w-4 h-4 text-zinc-400 transition-transform ${openPolicy === 'terms' ? 'rotate-180' : ''}`} />
            </button>

            {openPolicy === 'terms' && (
              <div className="p-4 pt-1 border-t border-zinc-800/80 text-xs text-zinc-300 space-y-2">
                <p>• <strong>Prepaid Only:</strong> All orders are prepaid via UPI (<code className="text-amber-400">{STORE_UPI_ID}</code>). Cash on delivery is not available.</p>
                <p>• <strong>Stock Availability:</strong> Orders are subject to size availability at the time of WhatsApp confirmation.</p>
                <p>• <strong>Privacy:</strong> We use your details (name, phone, address) solely to process and dispatch your order. We never sell your data.</p>
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
};
