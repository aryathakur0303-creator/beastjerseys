import React from 'react';
import { SIZING_GUIDE } from '../data/jerseys';
import { X, Ruler, Check } from 'lucide-react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div 
        className="relative w-full max-w-lg bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl p-5 sm:p-6 space-y-4"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2 text-white font-bold text-base">
            <Ruler className="w-5 h-5 text-amber-400" />
            <span>Jersey Size Guide</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-zinc-400">
          Our 2026/27 Fan Version jerseys have a comfortable, true-to-size supporter cut. Compare your measurements below:
        </p>

        <div className="overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-900/60">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400 font-semibold bg-zinc-900">
                <th className="py-2.5 px-3">Size</th>
                <th className="py-2.5 px-3">Chest (Inches)</th>
                <th className="py-2.5 px-3">Length</th>
                <th className="py-2.5 px-3">Fit Advice</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800 text-zinc-300">
              {SIZING_GUIDE.map((row) => (
                <tr key={row.size} className="hover:bg-zinc-800/40">
                  <td className="py-3 px-3 font-bold text-amber-400 flex items-center gap-1.5">
                    <span className="w-6 h-6 rounded bg-zinc-800 flex items-center justify-center text-xs">
                      {row.size}
                    </span>
                    <span>({row.size === 'M' ? 'Medium' : 'Large'})</span>
                  </td>
                  <td className="py-3 px-3 font-semibold text-white">{row.chestInches}</td>
                  <td className="py-3 px-3">{row.lengthInches} ({row.lengthCm})</td>
                  <td className="py-3 px-3 text-[11px] text-zinc-400">{row.recommendedHeight} · {row.recommendedWeight}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 space-y-1">
          <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
            <Check className="w-3.5 h-3.5" />
            <span>Quick Recommendation:</span>
          </div>
          <p className="text-[11px] text-zinc-400">
            • <strong>Size M:</strong> Best for chest 38–40 in, height under 5&apos;9&quot;, weight 60–72 kg.
          </p>
          <p className="text-[11px] text-zinc-400">
            • <strong>Size L:</strong> Best for chest 40–42 in, height 5&apos;9&quot;–6&apos;1&quot;, weight 72–84 kg, or if you prefer a looser fit.
          </p>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold transition-colors cursor-pointer"
        >
          Got it
        </button>
      </div>
    </div>
  );
};
