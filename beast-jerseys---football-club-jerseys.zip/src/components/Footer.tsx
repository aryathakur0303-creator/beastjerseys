import React from 'react';
import { STORE_PHONE, STORE_WHATSAPP_URL } from '../data/jerseys';
import { MessageCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-zinc-950 border-t border-zinc-800 text-zinc-400 text-xs py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-4 text-center sm:text-left">
        
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-base font-extrabold text-white tracking-tight">
              BEAST JERSEYS
            </span>
            <p className="text-xs text-zinc-400">
              Wear Your Club. Show Your Passion.
            </p>
          </div>

          <div>
            <a
              href={`${STORE_WHATSAPP_URL}?text=${encodeURIComponent('Hi Beast Jerseys, I have a question.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-emerald-400 border border-zinc-800 transition-colors font-medium text-xs"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>WhatsApp: {STORE_PHONE}</span>
            </a>
          </div>
        </div>

        <div className="pt-4 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-zinc-500">
          <div>
            © {new Date().getFullYear()} Beast Jerseys. All rights reserved.
          </div>
          <div>
            Real Madrid & FC Barcelona 2026/27 Football Jerseys
          </div>
        </div>

      </div>
    </footer>
  );
};
