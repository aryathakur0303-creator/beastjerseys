import { JerseyProduct } from '../types';

export const STORE_PHONE = '8897573208';
export const STORE_WHATSAPP_URL = 'https://wa.me/918897573208';
export const STORE_UPI_ID = 'aryathakur03.03@oksbi';
export const STORE_EMAIL = 'aryathakur03.03@gmail.com';
export const STORE_INSTAGRAM = 'beast.jersey';
export const STORE_INSTAGRAM_URL = 'https://www.instagram.com/beast.jersey/';

export interface JerseyProductWithImage extends JerseyProduct {
  imageUrl: string;
}

export const FAN_VERSION_JERSEYS: JerseyProductWithImage[] = [
  {
    id: 'real-madrid-away-fan',
    name: 'Real Madrid 2026/27 Jersey',
    club: 'Real Madrid',
    season: '2026/27',
    type: 'Away Edition',
    version: 'Fan Version',
    price: 299,
    originalPrice: 999,
    delivery: 'FREE',
    imageUrl: '/assets/aistudio/WhatsApp_Image_2026-10-23_at_1.38.50_PM_1ba5ad3d.jpeg',
    stock: { M: 2, L: 2 },
    description:
      'Los Blancos 2026/27 teal and white away edition with RMCF all-over graphic pattern, classic Trefoil Adidas emblem, and Emirates Fly Better branding. Comfortable supporter cut for everyday wear.',
    colors: {
      primary: '#0d4754',
      secondary: '#ffffff',
      accent: '#26c6da',
      collar: '#26c6da',
    },
    features: [
      'Relaxed regular supporter fit for match days and street style',
      'Woven Real Madrid club crest with crown detail',
      'All-over geometric RMCF monogram pattern',
      'Lightweight, breathable fabric designed for comfort',
      'Emirates Fly Better front sponsor and HP sleeve transfer',
    ],
    careInstructions: [
      'Machine wash gentle cycle cold (inside out)',
      'Do not bleach or tumble dry high',
      'Cool iron inside out; avoid direct heat on sponsors',
    ],
  },
  {
    id: 'barcelona-away-fan',
    name: 'FC Barcelona 2026/27 Jersey',
    club: 'FC Barcelona',
    season: '2026/27',
    type: 'Away Edition',
    version: 'Fan Version',
    price: 299,
    originalPrice: 999,
    delivery: 'FREE',
    imageUrl: '/assets/aistudio/WhatsApp_Image_2026-10-23_at_1.38.49_PM_cd79ff1e.jpeg',
    stock: { M: 2, L: 2 },
    description:
      'FC Barcelona 2026/27 Black and Purple gradient edition featuring the iconic Kobe Bryant Sheath crest, Barca shield, and vibrant Spotify emblem. Built for everyday comfort.',
    colors: {
      primary: '#1c1626',
      secondary: '#8a2be2',
      accent: '#facc15',
      collar: '#8a2be2',
    },
    features: [
      'Comfortable supporter cut tailored for relaxed daily wear',
      'Iconic Kobe Bryant Sheath emblem & FC Barcelona crest',
      'Striking dark black to royal purple gradient body',
      'Yellow circular Spotify chest sponsor badge',
      'Ventilated side seam mesh and Ambilight TV sleeve detail',
    ],
    careInstructions: [
      'Wash inside out in cold water',
      'Line dry away from harsh direct sun',
      'Do not iron over sponsor transfers',
    ],
  },
];

// Currently no Player Version in stock as requested
export const PLAYER_VERSION_JERSEYS: JerseyProductWithImage[] = [];

export const SIZING_GUIDE = [
  {
    size: 'M' as const,
    chestInches: '38 - 40 in',
    chestCm: '96 - 102 cm',
    lengthInches: '28 in',
    lengthCm: '71 cm',
    recommendedHeight: "5'6\" - 5'9\" (168 - 175 cm)",
    recommendedWeight: '60 - 72 kg',
  },
  {
    size: 'L' as const,
    chestInches: '40 - 42 in',
    chestCm: '102 - 107 cm',
    lengthInches: '29 in',
    lengthCm: '74 cm',
    recommendedHeight: "5'9\" - 6'1\" (175 - 185 cm)",
    recommendedWeight: '72 - 84 kg',
  },
];
