export interface PolicySectionData {
  id: string;
  title: string;
  shortDescription: string;
  content: {
    heading?: string;
    paragraphs?: string[];
    bullets?: string[];
    callout?: string;
  }[];
}

export const HOW_TO_ORDER_STEPS = [
  {
    step: 1,
    title: 'Choose Your Jersey',
    detail: 'Pick your preferred club away kit — Real Madrid or FC Barcelona.',
  },
  {
    step: 2,
    title: 'Select Your Size',
    detail: 'Select size M or L, subject to real-time stock availability.',
  },
  {
    step: 3,
    title: 'Contact Us on WhatsApp',
    detail: 'Message us on WhatsApp at 8897573208 to confirm stock and your order details.',
  },
  {
    step: 4,
    title: 'Complete Prepaid Payment',
    detail: 'Complete your prepaid payment using our verified UPI ID: aryathakur03.03@oksbi.',
  },
  {
    step: 5,
    title: 'Share Confirmation',
    detail: 'Share your UPI payment screenshot/UTR reference along with your delivery address.',
  },
  {
    step: 6,
    title: 'Dispatch & Tracking',
    detail: 'We confirm your order and provide shipping and tracking details for direct dispatch.',
  },
];

export const POLICIES_DATA: PolicySectionData[] = [
  {
    id: 'payment',
    title: 'Payment Policy',
    shortDescription: 'Prepaid orders via UPI only. No COD.',
    content: [
      {
        heading: 'Prepaid Orders Only',
        paragraphs: [
          'Beast Jerseys currently accepts prepaid orders only. Cash on Delivery (COD) is not available.',
          'Payment must be completed before an order is confirmed for processing and dispatch.',
        ],
        bullets: [
          'Accepted payment method: UPI (Google Pay, PhonePe, Paytm, BHIM, Cred, any UPI app).',
          'Official UPI ID: aryathakur03.03@oksbi',
          'Cash on Delivery (COD): NOT AVAILABLE.',
          'Customers should confirm product availability, size, and total order details before payment.',
          'Please retain your payment confirmation screenshot or UTR number until your order has been delivered.',
        ],
        callout: 'Important Security Reminder: Never share your UPI PIN, OTP, or banking password with anyone. Beast Jerseys will never ask for your PIN.',
      },
    ],
  },
  {
    id: 'shipping',
    title: 'Shipping & Delivery Policy',
    shortDescription: 'FREE delivery across India included in ₹299.',
    content: [
      {
        heading: 'Free Delivery & Logistics',
        paragraphs: [
          'FREE DELIVERY is included in the advertised price of ₹299 per jersey. There are zero hidden courier or packaging fees.',
          'Delivery timelines will be communicated directly on WhatsApp after order confirmation and dispatch package handover.',
          'Dispatch and delivery may be affected by courier operations, national holidays, weather conditions, or circumstances outside our control.',
          'Customers must provide an accurate delivery address, complete pin code, and a reachable mobile phone number for seamless courier handover.',
          'Please contact us directly on WhatsApp at 8897573208 if your shipment is delayed or if you need an update on your order.',
        ],
        callout: 'We aim to communicate clearly and keep customers informed throughout the entire order and shipping process.',
      },
    ],
  },
  {
    id: 'returns',
    title: 'Return, Exchange & Refund Policy',
    shortDescription: 'Mandatory unedited package-opening video for verified defects.',
    content: [
      {
        heading: '1. Returns',
        paragraphs: [
          'We generally do not accept returns for reasons such as a change of mind, incorrect size selection by the customer, or personal preference.',
          'Please confirm the jersey, size, and order details carefully before making payment.',
        ],
      },
      {
        heading: '2. Exchanges',
        paragraphs: [
          'Exchanges are considered only when the product has a genuine defect or damage attributable to Beast Jerseys or the product supplied by us.',
        ],
        bullets: [
          'Record a clear, continuous video while opening the original, unopened package.',
          'The video must show the outer package, courier label, and the product clearly, including the alleged defect.',
          'Contact us promptly on WhatsApp (8897573208) after receiving the order and provide the unedited package-opening video and order details.',
          'Our team will review the evidence and confirm whether the issue qualifies for an exchange.',
        ],
        callout: 'Package-opening video evidence is strictly required to help us verify damage or defects. Please keep the original packaging until the issue has been resolved.',
      },
      {
        heading: '3. Refunds',
        paragraphs: [
          'We do not offer refunds for change of mind, incorrect size selection, or personal preference.',
          'However, this policy does not exclude any refund or other remedy that may be required under applicable consumer protection laws. If a product is defective, incorrect, or otherwise qualifies for a legally required remedy, we will address the matter in accordance with applicable law.',
        ],
      },
      {
        heading: '4. Wrong or Defective Products',
        paragraphs: [
          'If you receive an incorrect item or a product with a verified defect attributable to us, contact us promptly with your order details and clear evidence. We will review the case and communicate the appropriate resolution.',
          'Please note: Customers should inspect their order as soon as it arrives and retain the package and packaging materials until they are satisfied with the product.',
        ],
      },
    ],
  },
  {
    id: 'privacy',
    title: 'Privacy Policy',
    shortDescription: 'Responsible handling and protection of your personal information.',
    content: [
      {
        heading: 'Information We Collect',
        paragraphs: [
          'At Beast Jerseys, we respect your privacy and aim to handle your personal information responsibly. When you place an order, we may collect:',
        ],
        bullets: [
          'Your full name.',
          'Your active phone / WhatsApp number.',
          'Your complete delivery address and postal code.',
          'Your selected jersey, size, and quantity.',
          'Payment confirmation or transaction reference details needed to verify your order.',
        ],
        callout: 'Please do not send your UPI PIN, OTP, or banking password.',
      },
      {
        heading: 'How We Use Your Information',
        paragraphs: ['We use your information strictly to:'],
        bullets: [
          'Confirm and process your football jersey orders.',
          'Verify prepaid UPI transactions.',
          'Arrange courier dispatch and door delivery.',
          'Contact you regarding dispatch updates or courier coordination.',
          'Resolve order-related questions and customer service requests.',
          'Meet applicable legal and recordkeeping obligations.',
        ],
      },
      {
        heading: 'Sharing of Information & Data Security',
        paragraphs: [
          'We do not sell customers’ personal information. We may share the minimum necessary information with trusted courier partners and payment service providers solely when required to fulfil an order or operate our business.',
          'We take reasonable steps to protect customer information from unauthorized access, misuse, or disclosure. We retain order-related information only for as long as reasonably necessary for business, customer service, recordkeeping, and legal purposes.',
        ],
      },
      {
        heading: 'Your Privacy Rights & Contact',
        paragraphs: [
          'You may contact us at any time to ask about your personal information or request correction of inaccurate details, subject to applicable law.',
          'For privacy-related questions, contact Beast Jerseys at 8897573208.',
        ],
      },
    ],
  },
  {
    id: 'terms',
    title: 'Terms and Conditions',
    shortDescription: 'Key purchase agreements and customer terms.',
    content: [
      {
        heading: 'Agreement by Placing an Order',
        paragraphs: [
          'By placing an order with Beast Jerseys, you acknowledge and agree to the following terms:',
        ],
        bullets: [
          '1. All orders are strictly prepaid. Cash on Delivery (COD) is not available.',
          '2. Each jersey costs ₹299, including free delivery, unless a different promotional offer is clearly communicated.',
          '3. Orders are subject to real-time stock availability.',
          '4. Customers are responsible for selecting the correct jersey club and size (M or L).',
          '5. Product colours and appearance may vary slightly depending on lighting, photography, and screen settings.',
          '6. Exchanges for verified defects attributable to us are handled strictly according to our exchange policy with unedited package-opening video.',
          '7. Our policies are subject to applicable consumer protection and other laws. Nothing on this website removes rights that customers are legally entitled to exercise.',
          '8. We may update product availability, pricing, and website policies when necessary. Any changes will apply subject to applicable law.',
        ],
      },
    ],
  },
];
