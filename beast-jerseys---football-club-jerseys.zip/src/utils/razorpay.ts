declare global {
  interface Window {
    Razorpay?: any;
  }
}

export interface RazorpayPaymentSuccessResponse {
  razorpay_payment_id: string;
  razorpay_order_id?: string;
  razorpay_signature?: string;
}

export interface RazorpayCheckoutOptions {
  amount: number; // in INR (e.g. 299)
  orderName: string;
  description: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  onSuccess: (paymentId: string) => void;
  onDismiss?: () => void;
  onError?: (err: any) => void;
}

export function openRazorpayCheckout(options: RazorpayCheckoutOptions): boolean {
  const keyId = import.meta.env.VITE_RAZORPAY_KEY_ID || 'rzp_test_BeastJerseys2026';
  
  if (typeof window !== 'undefined' && window.Razorpay) {
    try {
      const rzpOptions = {
        key: keyId,
        amount: Math.round(options.amount * 100), // convert to paise
        currency: 'INR',
        name: 'Beast Jerseys',
        description: options.description || '2026/27 Football Jersey Order',
        theme: {
          color: '#fbbf24', // Amber brand accent
        },
        prefill: {
          name: options.customerName || '',
          contact: options.customerPhone || '',
        },
        notes: {
          address: options.customerAddress || '',
          store: 'Beast Jerseys',
        },
        handler: function (response: RazorpayPaymentSuccessResponse) {
          options.onSuccess(response.razorpay_payment_id || `pay_${Date.now().toString(36)}`);
        },
        modal: {
          ondismiss: function () {
            if (options.onDismiss) options.onDismiss();
          },
        },
      };

      const rzp = new window.Razorpay(rzpOptions);
      rzp.on('payment.failed', function (response: any) {
        console.error('Razorpay payment failed:', response.error);
        if (options.onError) {
          options.onError(response.error);
        }
      });
      rzp.open();
      return true;
    } catch (err) {
      console.warn('Razorpay SDK threw error on open, fallback available:', err);
      return false;
    }
  }

  return false;
}
