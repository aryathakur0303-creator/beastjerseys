import QRCode from 'qrcode';

export const STORE_UPI_ID = 'aryathakur03.03@oksbi';
export const STORE_PAYEE_NAME = 'Beast Jerseys';

export interface UPILinkOptions {
  amount?: number;
  note?: string;
  transactionRef?: string;
}

/**
 * Builds standard NPCI / UPI deep-link URL
 */
export function generateUPILink(options: UPILinkOptions = {}): string {
  const { amount = 299, note = 'Beast Jerseys 2026/27 Order' } = options;
  
  const params = new URLSearchParams();
  params.append('pa', STORE_UPI_ID);
  params.append('pn', STORE_PAYEE_NAME);
  if (amount > 0) {
    params.append('am', amount.toFixed(2));
  }
  params.append('cu', 'INR');
  params.append('tn', note);

  return `upi://pay?${params.toString()}`;
}

/**
 * Generates high-res DataURL for QR code rendering
 */
export async function generateUPIQRCode(options: UPILinkOptions = {}): Promise<string> {
  const upiLink = generateUPILink(options);
  try {
    const dataUrl = await QRCode.toDataURL(upiLink, {
      width: 320,
      margin: 1.5,
      color: {
        dark: '#09090b',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    });
    return dataUrl;
  } catch (err) {
    console.error('Failed to generate UPI QR code:', err);
    return '';
  }
}
